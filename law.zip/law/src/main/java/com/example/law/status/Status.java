package com.example.law.status;

import com.example.law.topic.Topic;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Status {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long dni;

    @Column(columnDefinition = "text", nullable = false)
    private String name;

    @OneToMany(mappedBy = "status")
    @JsonIgnore
    private List<Topic> topics;
}
