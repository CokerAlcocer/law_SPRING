package com.example.law.client;

import com.example.law.topic.Topic;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long dni;

    @Column(columnDefinition = "text", nullable = false)
    private String name;

    @Column(columnDefinition = "text", nullable = false)
    private String surname;

    @Column(columnDefinition = "text", nullable = false, unique = true)
    private String email;

    @OneToMany(mappedBy = "client")
    @JsonIgnore
    private List<Topic> topics;
}
