package com.example.law.topic;

import com.example.law.client.Client;
import com.example.law.lawyer.Lawyer;
import com.example.law.status.Status;

import javax.persistence.*;
import java.util.List;

@Entity
public class Topic {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long no;

    @Column(columnDefinition = "date", nullable = false)
    private String start_date;

    @Column(columnDefinition = "date", nullable = false)
    private String end_date;

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;

    @ManyToOne
    @JoinColumn(name = "status_id")
    private Status status;

    @ManyToMany
    @JoinTable(name = "lawyer_has_topic", joinColumns = @JoinColumn(name = "lawyer_id"),
    inverseJoinColumns = @JoinColumn(name = "topic_no"))
    private List<Lawyer> lawyers;

}
