package com.example.law.lawyer;

import com.example.law.topic.Topic;

import javax.persistence.*;
import java.util.List;

@Entity
public class Lawyer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(columnDefinition = "text", nullable = false)
    private String name;

    @Column(columnDefinition = "text", nullable = false)
    private String surname;

    @Column(columnDefinition = "text", nullable = false, unique = true)
    private String email;

    @ManyToMany(mappedBy = "lawyers")
    private List<Topic> topics;
}

